﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Session02
{
    class Program
    {
        static void Main(string[] args)
        {
            double area = 3.1452 * radius * radius;
        }
    }
}
