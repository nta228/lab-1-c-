﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example9
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("C# is a powerful programming language");
            Console.WriteLine("C# is a powerful");
            Console.WriteLine("programming language");
            Console.Write("C# is a powerful");
            Console.WriteLine(" programming language");
        }
    }
}
