﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example2
{
    class Program
    {
        static void Main(string[] args)
        {
            bool boolTest = true;
            short byTest = 19;
            int intTest;
            string stringTest = "David";
            float floatTest;
            intTest = 140000;
            floatTest = 14.5f;
            Console.WriteLine("boolTest={0}", boolTest);
            Console.WriteLine("byTest=" + byTest);
            Console.WriteLine("intTest=" + intTest);
            Console.WriteLine("stringTest=" + stringTest);
            Console.WriteLine("floatTes=" + floatTest);

        }
    }
}
