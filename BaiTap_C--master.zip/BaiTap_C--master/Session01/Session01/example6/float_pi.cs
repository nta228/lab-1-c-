﻿using System;

namespace example6
{
    internal class float_pi
    {
        public static implicit operator float_pi(float v)
        {
            throw new NotImplementedException();
        }
    }
}